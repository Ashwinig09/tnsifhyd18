package com.project1.demo.service;

import java.util.List;

import com.project1.demo.entity.College;

public interface CollegeService {

	College saveCollege(College college);

	List<College> fetchCollegeList();

	void deleteCollegeById(Long collegeId);

	College updateCollege(Long collegeId, College college);

	College fetchCollegeById(Long collegeId);

}
