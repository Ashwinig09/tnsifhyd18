package com.project1.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.project1.demo.entity.College;
import com.project1.demo.repository.CollegeRepository;

@Service
public class CollegeServiceImpl  implements CollegeService{
	
	@Autowired
	CollegeRepository cr;

	@Override
	public College saveCollege(College college) {
		return cr.save(college);
	}

	@Override
	public List<College> fetchCollegeList() {
		return cr.findAll();
	}

	@Override
	public void deleteCollegeById(Long collegeId) {
		cr.deleteById(collegeId);
		
	}

	@Override
	public College fetchCollegeById(Long collegeId) {
		return cr.findById(collegeId).get();
	}
	 @Override
	   public College updateCollege(Long collegeId, College college) {
	       College clgDB = cr.findById(collegeId).get();

	       if(Objects.nonNull(college.getCollegeName()) &&
	       !"".equalsIgnoreCase(college.getCollegeName())) {
	           clgDB.setCollegeName(college.getCollegeName());
	       }


	       if(Objects.nonNull(college.getCollegeAddress()) &&
	               !"".equalsIgnoreCase(college.getCollegeAddress())) {
	           clgDB.setCollegeAddress(college.getCollegeAddress());
	       }

	       
			return cr.save(clgDB);
		
	   }

	    

}
