package com.day5;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class DateTimeAPI {
public static void main(String[] args) {
	 LocalDateTimeApi();
	 }
	 public static  void LocalDateTimeApi()
	{
	  
	    // the current date
	    LocalDate date = LocalDate.now();
	    System.out.println("the current date is "+
	                        date);
	    LocalTime time = LocalTime.now();
	    System.out.println("the current time is "+
	                        time);
	      
	  
	    // will give us the current time and date
	    LocalDateTime current = LocalDateTime.now();
	    System.out.println("current date and time : "+
	                        current);
	    DateTimeFormatter format = 
	    	      DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");  
	    	   
	    	    String formatedDateTime = current.format(format);  
	    	    
	    	    System.out.println("in formatted manner "+
	    	                        formatedDateTime);
	    	
	    	  
	    	
}
}
