package com.day5;
@FunctionalInterface
public interface FunctionalInterface1 {
	public void demo();
	//public void menu(); it is not included because functional interface has 1 abstract method
}
