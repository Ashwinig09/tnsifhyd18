package com.day5;

public interface LambdaExpressionJavaCode8 {
public void name();
}
