package com.day5;

public class MainFunctionalInterface {
public static void main(String[] args) {
	MFunctionalInterface m=new MFunctionalInterface();
	m.demo();
}
}
