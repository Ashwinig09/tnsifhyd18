package com.day5;

public class MainLambdaExpressionJavaCode8 {
public static void main(String[] args) {
	LambdaExpressionJavaCode8 l1=()->
	{
		System.out.println("anusha");
	};
	l1.name();
}
}
