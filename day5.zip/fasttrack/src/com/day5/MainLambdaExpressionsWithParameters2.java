package com.day5;

public class MainLambdaExpressionsWithParameters2 {
public static void main(String[] args) {
	LambdaExpressionsWithParameters2 m=(a,b)->
	{
		System.out.println(a+b);
	};
	m.add(2, 3);
}
}
