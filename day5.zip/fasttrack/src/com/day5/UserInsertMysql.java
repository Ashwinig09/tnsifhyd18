package com.day5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserInsertMysql {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
			
				String dbURL = "jdbc:mysql://localhost:3306/db";
				String username = "root";
				String password = "anusha";
				 
				try {
				 
				    Connection conn = DriverManager.getConnection(dbURL, username, password);
				    String sql = "INSERT INTO dbtable (username, usersalary, useraddress) VALUES (?, ?, ?)";
				    PreparedStatement statement = conn.prepareStatement(sql);
				    statement.setString(1, "suresh");
				    statement.setString(2, "23000");
				    statement.setString(3, "chennai");
				    
				    PreparedStatement statement1 = conn.prepareStatement(sql);
				    statement1.setString(1, "anusha");
				    statement1.setString(2, "45000");
				    statement1.setString(3, "bangalore");
				   
				    PreparedStatement statement2 = conn.prepareStatement(sql);
				    statement2.setString(1, "shanmukhi");
				    statement2.setString(2, "25000");
				    statement2.setString(3, "punjab");
				   
				    PreparedStatement statement3 = conn.prepareStatement(sql);
				    statement3.setString(1, "ashwini");
				    statement3.setString(2, "30000");
				    statement3.setString(3, "delhi");
				  
				    int rowsInserted = statement.executeUpdate();
				    if (rowsInserted > 0) {
				        System.out.println("A new user1 was inserted successfully!");
				    }
				    int rowsInserted1 = statement1.executeUpdate();
				    if (rowsInserted1 > 0) {
				        System.out.println("A new user2 was inserted successfully!");
				    }
				    int rowsInserted2 = statement2.executeUpdate();
				    if (rowsInserted2 > 0) {
				        System.out.println("A new user3 was inserted successfully!");
				    }
				    int rowsInserted3 = statement3.executeUpdate();
				    if (rowsInserted3 > 0) {
				        System.out.println("A new user4 was inserted successfully!");
				    }
				} catch (SQLException ex) {
				    ex.printStackTrace();
				}

		


	}

}


