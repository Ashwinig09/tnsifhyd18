package com.day5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserRetrieveMysql {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
				String dbURL = "jdbc:mysql://localhost:3306/db";
				String username = "root";
				String password = "anusha";
				 
				try(Connection conn = DriverManager.getConnection(dbURL, username, password)) {
				 
					String sql = "SELECT * FROM dbtable";
					 
					Statement statement = conn.createStatement();
					ResultSet result = statement.executeQuery(sql);
					 
					int count = 80;
					 
					while (result.next()){
					    String salary = result.getString(3);
					   
					    String name = result.getString("username");
					    String address = result.getString("useraddress");
					 
					    String output = "empid #%d: %s - %s - %s ";
					    System.out.println(String.format(output, ++count, name, salary, address));
					}
				} catch (SQLException ex) {
				    ex.printStackTrace();
				}

			}
			}


