package com.day1;

public class Privatemodifier {
	
	private void display()
	{
	System.out.println("TNS Sessions");
	}
	/*public static void main(String[] args) {
		Privatemodifier a=new Privatemodifier();
		a.display();
	}*/
	}


