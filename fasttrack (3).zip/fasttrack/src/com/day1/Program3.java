package com.day1;
import java.util.*;
public class Program3 {
public static void main(String[] args) {
	{
		Scanner input= new Scanner(System.in);
		System.out.println("enter a number");
		int i,num,fact=1;
		num=input.nextInt();
		for(i=1;i<=num;i++)
		{
			fact=fact*i;
		}
		System.out.println("factorial of"+num+"\nis\n"+fact);
	}
}
}
