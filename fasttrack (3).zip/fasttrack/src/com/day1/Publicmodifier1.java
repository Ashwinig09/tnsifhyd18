package com.day1;

public class Publicmodifier1 {
	public static void main(String[] args)
	{
		Publicmodifier obj = new Publicmodifier();
	obj.display();
	}
	}


