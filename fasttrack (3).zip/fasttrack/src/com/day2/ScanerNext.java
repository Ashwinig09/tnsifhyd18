package com.day2;

import java.util.Scanner;

public class ScanerNext {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
	    System.out.print("Enter your name: ");
	    // reads the entire word
	    String value = sc.next();
	    System.out.println("Name: " + value);
	    sc.close();

	}

}
