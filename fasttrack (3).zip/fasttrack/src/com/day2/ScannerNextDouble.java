package com.day2;

import java.util.Scanner;

public class ScannerNextDouble {
	public static void main(String[] args) {
		
	
    Scanner input = new Scanner(System.in);
    System.out.print("Enter Double value: ");
    // reads the double value
    double value = input.nextDouble();
    System.out.println("The double value is: " + value);
    input.close();
	}

}
