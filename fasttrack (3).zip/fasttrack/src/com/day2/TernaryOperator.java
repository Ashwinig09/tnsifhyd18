package com.day2;

import java.util.Scanner;

public class TernaryOperator {
	public static void main(String[] args) {
		boolean x;
		x = (5<4)?true:false;
		System.out.println(x);

	}

}
