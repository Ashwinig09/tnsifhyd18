package com.day3;

public abstract class Animal2 {
	
	public void sleep() {
		System.out.println("sleeping");
	}
	
	public abstract void eat();

}
