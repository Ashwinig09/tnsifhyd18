package com.day3;

public class Aparent {
	
		void show()
		{
			System.out.println("Parent's show()");
		}
	}
	
	

	


