package com.day3;

public class Bird {
  void eat()
  {
	  System.out.println("eating");
  }
}
class ChildBird extends Bird
{
	void sleep()
	{
		System.out.println("sleeping");
	}
}
class ChildBird1 extends Bird
{
	void sing()
	{
		System.out.println("singing");
	}
}