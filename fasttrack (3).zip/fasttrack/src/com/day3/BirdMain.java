package com.day3;

public class BirdMain {
	public static void main(String[] args) {
		ChildBird1 c=new ChildBird1();
		c.eat();
		//c.sleep();
		c.sing();
	}

}
