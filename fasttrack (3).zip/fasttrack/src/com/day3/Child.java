package com.day3;

public class Child extends Aparent {
	   @Override
	    void show()
	    {
	    	System.out.println("Child's show()");
	    }

}
