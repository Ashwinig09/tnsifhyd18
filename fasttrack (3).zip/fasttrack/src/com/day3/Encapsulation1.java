package com.day3;

public class Encapsulation1 {
	
	public static void main(String[] args) {
		
		Encapsulation e3 = new Encapsulation();
		e3.setAge(20);
		e3.setGender("Female");
		e3.setName("Varsha");
		
		System.out.println(e3.getAge());
		System.out.println(e3.getGender());
		System.out.println(e3.getName());
		
	}
}
