package com.day3;

public class Main {
	public static void main(String[] args)
    {
       
       // Aparent obj1 = new Aparent();
       // obj1.show();
 
        
        Aparent obj2 = new Child();
        obj2.show();
    }

}
