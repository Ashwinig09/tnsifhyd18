package com.day3;

public class MainAbstract {
	
	public static void main(String[] args) {
		Animal2 c = new cow();
		c.sleep();
		c.eat();
		System.out.println("=======================");
		Animal2 t = new Tiger();
		t.sleep();
		t.eat();
	}

}
