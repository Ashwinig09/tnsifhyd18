package com.day3;

public class MultilevelInheritance1 {
public static void main(String[] args) {
	BabyDog d = new BabyDog();
	d.weep();
	d.bark();
	d.eat();
}
}
