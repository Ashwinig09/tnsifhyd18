package com.day3;

class Animal1
{
	void bark()
	{
		System.out.println(" barking");
	}
}
class Dog1 extends Animal1
{
	void eat()
	{
		System.out.println("eating");
	}
}
class BabyDog extends Dog1
{ 
	void weep()
	{
		System.out.println("weeping");
	}
	
}