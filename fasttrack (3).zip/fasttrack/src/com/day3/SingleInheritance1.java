package com.day3;


	class SingleInheritance1
	{  
	   public static void main(String args[])
	   {  
	      Dog d=new Dog();  
	      d.bark();  
	      d.eat();  
	   }
	}


