package com.day3;

public class Tiger extends Animal2 {
	

	@Override
	public void eat() {
		System.out.println("Eats animals");
	}

}
