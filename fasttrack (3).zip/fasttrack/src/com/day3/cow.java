package com.day3;

public class cow extends Animal2{
	
	@Override
	public void eat() {
		System.out.println("Eats Grass");
	}

}
