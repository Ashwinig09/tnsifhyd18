package com.day4;

public class Array1 {
 public static void main(String[] args) {
	int[] a = new int[4];
	a[0]=25;
	a[1]=26;
	a[2]=27;
	a[3]=28;
	//printing array
	for(int i=0;i<a.length;i++)
	{
		System.out.println("The array list: "  + a[i]);
	}
			
	
}
}
