package com.day4;

public class ArrayOfObjectMain {
public static void main(String[] args) {
	ArrayOfObjects arr[]= new ArrayOfObjects[4];
	arr[0]= new ArrayOfObjects(1,"Ashwini");
	arr[1]= new ArrayOfObjects(2,"Anjali");
	arr[2]= new ArrayOfObjects(3,"anusha");
	arr[3]= new ArrayOfObjects(4,"varsha");
	for(int i=0;i<arr.length;i++)
	{
		System.out.println("Elements at"+ i + ":" + arr[i].id + " " + arr[i].name );
	}
}
}
