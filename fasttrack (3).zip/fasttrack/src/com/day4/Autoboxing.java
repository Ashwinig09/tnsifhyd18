package com.day4;

public class Autoboxing {
public static void main(String[] args) {
	int a=5;
	double b =6.5;
	Integer  aobj = Integer.valueOf(a);
	Double bobj = Double.valueOf(b);
	if(aobj instanceof Integer)
	{
		System.out.println(" An object of integer is created");
	}
	if(bobj instanceof Double)
	{
		System.out.println(" An object of double is created");
	}
}
}
