package com.day4;

public class Child implements Parent1,Parent2 {

	@Override
	public void content1() {
		System.out.println("Display the information in content1");
		
	}

	@Override
	public void content() {
		System.out.println("Display the information in content");
		
	}

}
