package com.day4;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {
    public static void main(String args[])
    {
        HashSet<String> h= new HashSet<String>();

        h.add("Welcome");
        h.add("to");
        h.add("Sri indu college ");
        Iterator<String> ir = h.iterator();
        while (ir.hasNext()) {
            System.out.println(ir.next());
        }
    }


}
