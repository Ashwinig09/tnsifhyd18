package com.day4;

public class Main1 {
public static void main(String[] args) {
	Child d = new Child();
	d.content();
	d.content1();
}
}
