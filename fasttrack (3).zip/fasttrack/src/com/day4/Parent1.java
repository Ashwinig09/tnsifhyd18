package com.day4;

public interface Parent1 {
	abstract void content();

}


