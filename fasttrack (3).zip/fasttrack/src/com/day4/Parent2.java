package com.day4;

public interface Parent2 {
	 abstract void content1();
}
