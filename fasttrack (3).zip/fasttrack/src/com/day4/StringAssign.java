package com.day4;

public class StringAssign {
	public static void main(String args[]){  
		   String s1="Sachin";  
		   String s2="virat";  
		   String s3=new String("Sachin");  
		   System.out.println(s1==s2);  
		   System.out.println(s1==s3); 
		 }  

}
