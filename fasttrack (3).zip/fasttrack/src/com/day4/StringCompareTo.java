package com.day4;

public class StringCompareTo {
	 public static void main(String args[]){  
		   String s1="Ashwini";  
		   String s2="ashwini";  
		   String s3="Varsha";  
		   System.out.println(s1.compareTo(s3));
		   System.out.println(s2.compareTo(s3));
		   System.out.println(s3.compareTo(s2));
		 }  

}
