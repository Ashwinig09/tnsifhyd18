package com.day4;

public class StringEqualsIgnore {
	public static void main(String args[]){  
		   String s1="Sachin";  
		   String s2="SACHIN";  
		  
		   System.out.println(s1.equals(s2));  
		   System.out.println(s1.equalsIgnoreCase(s2));  
		     
		 }  

}
