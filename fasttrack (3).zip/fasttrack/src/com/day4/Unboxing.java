package com.day4;

public class Unboxing {
public static void main(String[] args) {
	Integer  aobj = Integer.valueOf(5);
	Double bobj = Double.valueOf(6.5);
	int a = aobj.intValue();
	double b = bobj.doubleValue();
	System.out.println("The value of a:" + a);
	System.out.println("The value of b:" + b);
	
}
}
