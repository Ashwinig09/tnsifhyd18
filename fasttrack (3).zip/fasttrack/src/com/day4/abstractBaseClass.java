package com.day4;

 abstract class Base{
	
		abstract void Display();
		
	}
class Derived extends Base
{
	void Display()
	{
		System.out.println("The content of Drived class");
	}
}


