package com.day4;

public class main {
  public static void main(String[] args) {
	//Base b = new Base();
	Base b = new Derived();
	b.Display();
}
}
