package com.day1;

public class Default {

	//Class MyClass1 is having Default access modifier
	
	void disp()
	{
	System.out.println("Hello World!");
	}
	}


