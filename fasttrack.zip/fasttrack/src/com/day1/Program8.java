package com.day1;
import java.util.*;
public class Program8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner=new Scanner(System.in);
System.out.println("enter a string");
	String str=scanner.nextLine();
	String reversedstr="";
	for(int i=str.length()-1;i>=0;i--){
		reversedstr+=str.charAt(i);
		
	}
	if(str.equals(reversedstr))
		{
		System.out.println(str+"is palindrome");
		}
	else
	{
		System.out.println(str+"is not palindrome");
	}

}
}

