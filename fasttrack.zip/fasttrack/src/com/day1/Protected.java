package com.day1;

public class Protected {
 protected void display1()
	{
	System.out.println("TNS Sessions");
	}

}


