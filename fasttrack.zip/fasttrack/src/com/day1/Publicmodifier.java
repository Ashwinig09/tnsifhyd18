package com.day1;

public class Publicmodifier {
	
		public void display()
		{
		System.out.println("TNS Sessions");
		}
		}


