package com.day2;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Scanner;

public class ScannerMethods {
	public static void main(String[] args) {
		Scanner input1 = new Scanner(System.in);
	    System.out.print("Enter a big integer: ");
	    BigInteger n1 = input1.nextBigInteger();
	    System.out.println("The BigInteger value: " + n1);
	   
	    
	    System.out.print("Enter a big decimal: ");
	    BigDecimal n2 = input1.nextBigDecimal();
	    System.out.println("The BigDecimal value: " + n2);
	 
	    
	    System.out.println("enter short integer");
	    Scanner input3 = new Scanner(System.in);
	    short n3 = input3.nextShort();
	    System.out.println("the ShortInteger value:" + n3);
	   
	    
	    System.out.println("enter short Byte");
	    Scanner input4 = new Scanner(System.in);
	    Byte n4 = input4.nextByte();
	    System.out.println("the Byte value:" + n4);
	   
	    
	  }

	}


