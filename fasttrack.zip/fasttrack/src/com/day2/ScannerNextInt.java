package com.day2;

import java.util.Scanner;

public class ScannerNextInt {
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
	    System.out.println("Enter an integer: ");
	    
	    int num = input.nextInt();
	    System.out.println("The integer is: " + num);
	    input.close();

	}

}
